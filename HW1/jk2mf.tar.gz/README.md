# Basic Shell

This is my implementation of a basic shell, homework 1 for the operating systems course.

## Makefile
In the project directory, you can run:
### `make`
Compiles the code.

### `make test`
Runs the test script