#include <stdbool.h>

#include "storage.h"

int uva_open(char* filename, bool writeable) {
	return -1;
}

int uva_close(int file_identifier) {
	return -1;
}

int uva_read(int file_identifier, char* buffer, int offset, int length) {
	return -1;
}

int uva_read_reset(int file_identifier) {
	return -1;
}

int uva_write(int file_identifier, char* buffer, int length) {
	return -1;
}
